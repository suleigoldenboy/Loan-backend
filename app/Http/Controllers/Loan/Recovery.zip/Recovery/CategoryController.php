<?php

namespace App\Http\Controllers\Loan\Recovery;

use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\Loan\Loan;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Get Performing Loan
     * @param  Object Illuminate\Http\Request
     * @return Object Illuminate\Http\Response
    */
    public function getPerformingLoan(Request $request)
    {
       $performingLoan = Loan::whereDate('release_date', '<', Carbon::now()->subMonth())->get();
       return view('admin.loan.recovery.categories', ['loans' => $performingLoan]);
    }
}
